<?php

class Asadikin_CustomHead_Model_SetPlace{

    public function toOptionArray() {
        $results = [
            array('value'=>'home','label'=>'Homepage'),
            array('value'=>'product','label'=>'Product List')
        ];

        return $results;
    }
}