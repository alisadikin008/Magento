<?php
class Asadikin_CustomHead_Block_Head extends Mage_Core_Block_Template{

    public function isModuleActive(){
        $webId = $this->getWebId();
        $value = Mage::app()->getWebsite($webId)->getConfig('customhead_general/general/active');
        return $value;
    }

    public function getSetPlace(){
        $webId = $this->getWebId();
        $value = Mage::app()->getWebsite($webId)->getConfig('customhead_general/general/setplace');
        return $value;
    }
    public function getScript(){
        $webId = $this->getWebId();
        $value = Mage::app()->getWebsite($webId)->getConfig('customhead_general/general/script_text');
        return $value;
    }
    # get current web Id
    public function getWebId(){
        return Mage::app()->getWebsite()->getId();
    }

}